from setuptools import setup

setup(name='my_open_weather',
      version='0.0',
      description='weather',
      packages=['my_open_weather'],
      author_email='21qquestions@gmail.com',
      zip_safe=False)

